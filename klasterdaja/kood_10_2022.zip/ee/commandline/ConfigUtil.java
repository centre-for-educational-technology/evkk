package ee.commandline;

import org.apache.commons.cli.*;

public class ConfigUtil {

    private String fileParameter = "f";
    private String userNameParameter = "u";
    private String morphoTag = "m";
    private String syntacticalTag = "s";
    private String punctuationTag = "z";
    private String clusterSizeParameter = "k";
    private String estmorfParser = "e";
    private String wordTag = "w";
    private CommandLine commands;

    public ConfigUtil(String[] args) throws ParseException {
        CommandLineParser parser = new GnuParser();
        Options options = new Options();
        options.addOption(fileParameter, true, "File to analyse");
        options.addOption(userNameParameter, true, "Owner of file");
        options.addOption(morphoTag, false, "morphological Tag");
        options.addOption(syntacticalTag, false, "syntactical Tag");
        options.addOption(punctuationTag, false, "punctuations");
        options.addOption(clusterSizeParameter, true, "cluster size");
        options.addOption(estmorfParser, false, "estmorf parser");
        options.addOption(wordTag, false, "word Tag Analysis");
        commands = parser.parse(options, args);
        validateCommands(commands);
    }

    void validateCommands(CommandLine commands) {
        if (!commands.hasOption(fileParameter)) {
            throw new IllegalArgumentException();
        }
        if (!commands.hasOption(clusterSizeParameter)){
        }
    }

    public String getInputFileName() {
        return commands.getOptionValue(fileParameter).trim();
    }

    public boolean hasUserNameArgument() {
        return commands.hasOption(userNameParameter);
    }

    public String getUserName() {
        return commands.getOptionValue(userNameParameter).trim();
    }

    public boolean isMorphologicalTag() {
        return commands.hasOption(morphoTag);
    }

    public boolean isSyntacticalTag() {
        return commands.hasOption(syntacticalTag);
    }

    public boolean isPunctuationTag() {
        return commands.hasOption(punctuationTag);
    }

    public boolean isWordTag() {
        return commands.hasOption(wordTag);
    }

    public boolean hasClusterSizeArgument(){
        return commands.hasOption(clusterSizeParameter);
    }

    public int getClusterSize() {
        return Integer.parseInt(commands.getOptionValue(clusterSizeParameter).trim());
    }

    public boolean isEstmorfParser() {
        return commands.hasOption(estmorfParser);
    }
}
