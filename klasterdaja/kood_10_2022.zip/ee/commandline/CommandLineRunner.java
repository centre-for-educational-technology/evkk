package ee.commandline;

import ee.clusters.AnalyzerSettings;
import ee.clusters.ClusterManager;
import ee.filemanagment.FileManager;
import ee.words.WordTagExtractor;
import ee.words.parser.FileStructureParseException;
import ee.words.parser.estmorf.EstmorfParser;
import org.apache.commons.cli.ParseException;

import java.io.File;

public class CommandLineRunner {
    private FileManager fileManager;
    private ClusterManager clusterManager;
    private ConfigUtil config;
    private AnalyzerSettings settings;

    public CommandLineRunner(String[] args) throws ParseException {
        config = new ConfigUtil(args);
        parseSettingsFromArguments();
        fileManager = new FileManager();
        clusterManager = new ClusterManager();
        analyseFile();
    }

    public void analyseFile() {
        WordTagExtractor wordTagExtractor = new WordTagExtractor();
        clusterManager.setWordTagExtractor(wordTagExtractor);
        if(config.isEstmorfParser()){
            System.out.println("estmorf");
            EstmorfParser estmorfParser = new EstmorfParser();
            File file = new File(getFullFilePath());
            try {
                estmorfParser.setFile(file);
                estmorfParser.parseFile();
                wordTagExtractor.extractAllWordTagsFrom(estmorfParser.getWordObjects());
            } catch (Exception e) {
                e.printStackTrace();
            } catch (FileStructureParseException e) {
                e.printStackTrace();
            }
        }else{
            System.out.println("pole estmorf");
            wordTagExtractor.extractAllWordTags(fileManager.loadSelectedFile(getFullFilePath()).split("-----"));
        }
        clusterManager.getClusters(settings);
        clusterManager.getClusters().sortClusters();
        saveFile();
    }

    private void parseSettingsFromArguments(){
        settings = new AnalyzerSettings();
        boolean useDefaultSettings = true;
        if(config.isMorphologicalTag()){
            settings.morphologicalTags = true;
            useDefaultSettings = false;
        }
        if(config.isSyntacticalTag()){
            settings.syntacticalTags = true;
            useDefaultSettings = false;
        }
        if(config.isPunctuationTag()){
            settings.punctuation = true;
            useDefaultSettings = false;
        }
        if(config.hasClusterSizeArgument()){
            settings.setClusterSize(config.getClusterSize());
        }
        if(useDefaultSettings){
            settings.morphologicalTags = true;
        }
        if(config.isWordTag()){
            settings.wordTagAnalysis = true;
        }
    }

    public void saveFile() {
        if(config.hasUserNameArgument()){
            fileManager.saveClusterFile(config.getUserName(), config.getInputFileName().replace(".txt", ""), clusterManager);
        } else {
            fileManager.saveClusterFile(config.getInputFileName().replace(".txt", ""), clusterManager);
        }
    }

    public String getFullFilePath(){
        return System.getProperty("user.dir") + File.separator + config.getInputFileName();
    }

    public AnalyzerSettings getSettings() {
        return settings;
    }
}
