package ee.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;


public class ClusterView extends JPanel {
    JPanel textPanel = new JPanel();
    JPanel panel = new JPanel();
    JScrollPane textAreaScrollPane;
    JTextArea words = new JTextArea("");
    JScrollPane tableScrollPane;
    DefaultTableModel model = new DefaultTableModel();
    JTable table = new JTable(model);
    MainWindow mainWindow;

    public ClusterView(MainWindow main) {
        this.mainWindow = main;
        createWindow();
    }

    public void createWindow() {
        ((DefaultTableModel) model).addColumn(" # Mitu kordust");
        ((DefaultTableModel) model).addColumn("A");
        ((DefaultTableModel) model).addColumn("B");
        ((DefaultTableModel) model).addColumn("C");
        /*TableRowSorter sorter = new TableRowSorter(model);
		sorter.setComparator(3, new IntComparator());
        table.setRowSorter(sorter);*/
        setLayout(new BorderLayout());
        textPanel.setLayout(new BorderLayout());
        panel.setLayout(new BorderLayout());
        tableScrollPane = new JScrollPane();
        tableScrollPane.getViewport().add(table);
        //table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.getColumnModel().getColumn(3).setPreferredWidth(180);
        table.getColumnModel().getColumn(1).setPreferredWidth(180);
        table.getColumnModel().getColumn(2).setPreferredWidth(180);
        table.getColumnModel().getColumn(0).setPreferredWidth(30);
        tableScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        panel.add(table.getTableHeader(), BorderLayout.PAGE_START);
        panel.add(tableScrollPane, BorderLayout.CENTER);
        panel.setVisible(true);
        add(panel, BorderLayout.CENTER);
        textAreaScrollPane = new JScrollPane(words);
        textAreaScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        textAreaScrollPane.setPreferredSize(new Dimension(250, mainWindow.frame.getSize().height));
        textPanel.add(textAreaScrollPane, BorderLayout.CENTER);
        add(textPanel, BorderLayout.EAST);
        table.addMouseListener(new MousePressed());
        tableScrollPane.addMouseListener(new MousePressed());
    }

    public JPanel getPanel() {
        return this;
    }

    public void addClusterToTable(Object[] input) {
        ((DefaultTableModel) model).addRow(input);
        table.repaint();
    }

    class MousePressed extends MouseAdapter {

        public void MouseAdapter() {

        }

        @Override
        public void mousePressed(MouseEvent e) {
            ArrayList<String[]> clusterWords;
            JTable jtable = (JTable) e.getSource();
            clusterWords = mainWindow.getClusterWords(jtable.getSelectedRow());
            System.out.println(jtable.getSelectedRow());
            jtable.clearSelection();
            fillWords(clusterWords);
        }
    }

    public void clearTable() {
        int counter = model.getRowCount();
        for (int i = 0; i < counter; i++) {
            model.removeRow(0);
        }
    }

    public void repaintTable() {
        table.repaint();
    }

    private void fillWords(ArrayList<String[]> clusterWords) {
        String toShow = "";
        for (String[] clusterWord : clusterWords) {
            for (String aClusterWord : clusterWord) {
                if (aClusterWord != null)
                    toShow = toShow + aClusterWord + " ";
            }
            toShow = toShow + "\n";
        }
        //System.out.println(toShow);
        words.setText(toShow);
    }

    public void generateColumns(int length) {
        ((DefaultTableModel) model).setColumnCount(length);

    }
}
