package ee.ui;

import ee.clusters.AnalyzerSettings;
import ee.clusters.ClusterManager;
import ee.filemanagment.FileManager;
import ee.words.WordTag;
import ee.words.WordTagExtractor;
import ee.words.WordTags;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;


public class MainWindow {
    JFrame frame = new JFrame("Morfosüntaktiliste klastrite leidja");
    JTabbedPane tab = new JTabbedPane();
    JPanel content = new JPanel();
    JButton addTextButton = new JButton("Lisa Tekst");
    FileManager fileManager = new FileManager(this);
    WordTagExtractor wordTagExtractor = new WordTagExtractor();
    ClusterManager clusterManager = new ClusterManager(this);
    ClusterView clusterView = new ClusterView(this);
    //table
    public int[] tableRowColor;
    JScrollPane tableScrollPane;
    String[] columnNames = {"Sõna", "Märgend", "Paranda"};
    WordTableModel model = new WordTableModel(wordTagExtractor);
    JTable table = new JTable(model);
    JDialog optionsFrame = new Options(frame, this);
    final JFileChooser fileChooser = new JFileChooser();

    public MainWindow() {
        content.setLayout(new BorderLayout());
        createMenu();
        createTable();
        addButtons();
    }

    public void buildTable() {
        for (int i = 0; i < wordTagExtractor.getAllWordTags().size(); i++) {
            addWordToTable(wordTagExtractor.getWordTagAt(i));
        }
        colorTableRows();
    }

    public WordTag getWordTagAccordingToTableRow(int row) {
        return wordTagExtractor.getWordTagAccordingToTableRow(row);
    }

    public void addWordToTable(WordTags input) {
        input.addToTable(this);
    }

    public void addLineToTable(Object[] input) {
        ((DefaultTableModel) model).addRow(input);
    }

    public void addLineToClusterTable(Object[] input) {
        clusterView.generateColumns(input.length);
        clusterView.addClusterToTable(input);
    }

    public ArrayList<WordTag> getWordTagsForCluster(int size, int count) {
        return wordTagExtractor.getWordTagsForCluster(size, count);
    }

    public int getWordTagListSize() {
        return wordTagExtractor.getWordTagListSize();
    }

    public String getWordTagToSave(int counter) {
        return wordTagExtractor.getWordTagsToSave(counter);
    }

    public int getClusterListSize() {
        return clusterManager.getClusterSize();
    }

    public String getClusterToSave(int counter) {
        return clusterManager.getClusterForSaveAt(counter);
    }


    protected void morphoAnalyze() {
        wordTagExtractor.extractAllWordTags(fileManager.loadFile().split("-----"));
        clearTable();
        buildTable();
    }

    protected ArrayList<String> parseInput(String[] input) {
        return new ArrayList<String>();
    }


    private void createTable() {
        //table.setFocusable(false);
        //table.setRowSelectionAllowed(false);
        ((DefaultTableModel) model).addColumn("");
        ((DefaultTableModel) model).addColumn("");
        tableScrollPane = new JScrollPane();
        tableScrollPane.setPreferredSize(new Dimension(800, 600));
        tableScrollPane.getViewport().add(table);
        tableScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    }

    private void clearTable() {
        int counter = model.getRowCount();
        for (int i = 0; i < counter; i++) {
            model.removeRow(0);
        }
    }

    private void colorTableRows() {
        tableRowColor = new int[wordTagExtractor.getWordTagListSize() * 4];
        tableRowColor = wordTagExtractor.fillColorTable();
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.getColumnClass(1);
        table.getColumnModel().getColumn(0).setCellRenderer(new TableRowRender(this));
        table.getColumnModel().getColumn(1).setCellRenderer(new JCheckBoxRenderer(this));
        table.getColumnModel().getColumn(0).setPreferredWidth(730);
        table.getColumnModel().getColumn(1).setPreferredWidth(50);
    }

    public void updateColorTable() {
        tableRowColor = wordTagExtractor.updateColorTable(tableRowColor);
    }

    public void updateTable() {
        model.setRowCount(0);

        updateColorTable();
        buildTable();
        table.repaint();
    }

    public int getTableRowColor(int row) {
        return tableRowColor[row];
    }

    public void setSelected(int row) {
        wordTagExtractor.setWordTagAccordingToTableRow(row, true);
    }

    public void setDeselected(int row) {
        wordTagExtractor.setWordTagAccordingToTableRow(row, false);
    }

    public void analyzeClusters(AnalyzerSettings settings) {
        clusterView.clearTable();
        clusterManager.clearClusters();
        clusterView.repaintTable();
        clusterManager.getClusters(settings);
        clusterManager.printClusters();
    }

    private void addButtons() {
        addTextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TextInsert(fileManager);
            }
        });
        frame.add(tab, BorderLayout.PAGE_START);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        content.add(table.getTableHeader(), BorderLayout.PAGE_END);
        content.add(addTextButton, BorderLayout.PAGE_START);
        content.add(tableScrollPane, BorderLayout.PAGE_END);

        tab.add("Sõnade vaade", content);
        tab.add("Klastrite vaade", clusterView.getPanel());
        frame.pack();
        frame.setMinimumSize(new Dimension(800, 400));
        frame.setVisible(true);
    }

    private void createMenu() {
        JMenu file = new JMenu("Fail");
        JMenu data = new JMenu("Klastrid");
        file.setMnemonic('F');
        JMenuItem newFile = new JMenuItem("Uus");
        newFile.setMnemonic('U');
        file.add(newFile);
        JMenuItem saveFile = new JMenuItem("Salvesta");
        newFile.setMnemonic('S');
        file.add(saveFile);
        JMenuItem loadFile = new JMenuItem("Ava");
        newFile.setMnemonic('A');
        file.add(loadFile);

        JMenuItem quit = new JMenuItem("Sulge");
        newFile.setMnemonic('U');
        file.add(quit);
        data.setMnemonic('K');
        JMenuItem findClusters = new JMenuItem("Otsi Klastreid");
        findClusters.setMnemonic('O');
        data.add(findClusters);
        JMenuItem exportClusters = new JMenuItem("Ekspordi Klastrid");
        findClusters.setMnemonic('E');
        data.add(exportClusters);
        JMenuItem clearClusters = new JMenuItem("Kustuta Klastrid");
        clearClusters.setMnemonic('K');
        data.add(clearClusters);

        newFile.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                wordTagExtractor.clearAllWordTags();
                clusterView.clearTable();
                clusterManager.clearClusters();
                clusterView.repaintTable();
                clearTable();
            }
        });
        saveFile.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int returnValue = fileChooser.showSaveDialog(frame);
                if (returnValue == JFileChooser.APPROVE_OPTION)
                    fileManager.saveCurrentFile(fileChooser.getSelectedFile().toString());
            }
        });
        loadFile.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int returnValue = fileChooser.showOpenDialog(frame);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    wordTagExtractor.loadWordTags(fileManager.loadSelectedFile(fileChooser.getSelectedFile().toString()).split("-----"));
                    colorTableRows();
                    updateTable();
                }
            }
        });
        exportClusters.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int returnValue = fileChooser.showSaveDialog(frame);
                if (returnValue == JFileChooser.APPROVE_OPTION)
                    fileManager.saveClusterFile(fileChooser.getSelectedFile().toString(), clusterManager);
            }
        });
        quit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        findClusters.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                optionsFrame.setVisible(true);
            }
        });
        clearClusters.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clusterView.clearTable();
                clusterManager.clearClusters();
                clusterView.repaintTable();
            }
        });
        JMenuBar bar = new JMenuBar();
        frame.setJMenuBar(bar);
        bar.add(file);
        bar.add(data);
    }

    public ArrayList<String[]> getClusterWords(int selectedRow) {
        return clusterManager.getClusterWords(selectedRow);
    }

}
