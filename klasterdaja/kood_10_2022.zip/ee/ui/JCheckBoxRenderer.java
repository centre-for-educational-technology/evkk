package ee.ui;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import java.awt.*;

public class JCheckBoxRenderer extends JCheckBox implements TableCellRenderer {
    private MainWindow mainWindow;

    public JCheckBoxRenderer(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
        setHorizontalAlignment(JLabel.CENTER);
    }

    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus, int row, int column) {
        if (mainWindow.getTableRowColor(row) == 0) {
            setBackground(Color.LIGHT_GRAY);
        } else if (mainWindow.getTableRowColor(row) == 1) {
            setBackground(Color.white);
        } else if (mainWindow.getTableRowColor(row) == 2) {
            setBackground(Color.white);
        } else if (mainWindow.getTableRowColor(row) == 3) {
            setBackground(Color.green);
        } else {
            setBackground(Color.white);
        }
        if (value == null) {
            return null;
        }
        setSelected((value != null && ((Boolean) value).booleanValue()));
        return this;
    }

    // The following methods override the defaults for performance reasons
    public void validate() {
    }

    public void revalidate() {
    }

}