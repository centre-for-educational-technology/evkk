package ee.ui;

import ee.filemanagment.FileManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TextInsert extends JFrame {
    JFrame frame = new JFrame();
    Container content = getContentPane();
    JButton insertTextButton = new JButton("Sisesta");
    JTextArea textArea = new JTextArea("", 15, 50);
    JScrollPane textAreaScrollPane;
    FileManager fileManager;


    public TextInsert(FileManager fileManager) {
        this.fileManager = fileManager;
        frame.setSize(640, 480);
        setUpElements();
        addActionListeners();
        addElements();
    }

    private void setUpElements() {
        content.setLayout(new BorderLayout());
        insertTextButton.setSize(100, 40);
        textAreaScrollPane = new JScrollPane();
        textAreaScrollPane.getViewport().add(textArea);
        textAreaScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

    }

    private void addActionListeners() {
        insertTextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                insertText();
                setVisible(false);
            }
        });
    }

    private void insertText() {
        fileManager.setTextToSave(textArea.getText());
        fileManager.saveFile();
        fileManager.main.morphoAnalyze();
    }

    private void addElements() {
        //content.add(textArea,BorderLayout.PAGE_START);
        content.add(textAreaScrollPane, BorderLayout.CENTER);
        content.add(insertTextButton, BorderLayout.PAGE_END);
        pack();
        setVisible(true);
    }

}
