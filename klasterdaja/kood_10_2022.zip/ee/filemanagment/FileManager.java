package ee.filemanagment;

import ee.clusters.ClusterManager;
import ee.ui.MainWindow;
import ee.words.WordTagExtractor;
import ee.words.WordTags;

import java.io.*;

public class FileManager {

    public static final String OUTPUT_FILE_SUFFIX = ".csv";
    public static final String DEFAULT_OUTPUT_FILE = "ajutine" + OUTPUT_FILE_SUFFIX;
    private FileWriter fstream;
    private String currentFileName;
    private String toWrite;
    public MainWindow main;
    WordTagExtractor wordTagExtractor;

    public FileManager(MainWindow main) {
        this.main = main;
    }

    public FileManager() {
    }

    public void createFile(String filename) {
        currentFileName = filename + ".txt";
        try {
            fstream = new FileWriter(currentFileName);
            fstream.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error:" + e.getMessage());
        }
    }

    public void setTextToSave(String toWrite) {
        this.toWrite = toWrite;
    }

    public void gatherTextToSave(String input) {
        try {
            fstream = new FileWriter("salvestus.txt");
            BufferedWriter out = new BufferedWriter(fstream);
            out.write(input);
            out.close();
        } catch (IOException e) {
            System.err.println("Error:" + e.getMessage());
        }
    }

    public void saveFile() {
        if (currentFileName == null) {
            createFile("test");
        }
        try {
            fstream = new FileWriter(currentFileName);
            BufferedWriter out = new BufferedWriter(fstream);
            out.write(toWrite);
            out.close();
        } catch (IOException e) {
            System.err.println("Error:" + e.getMessage());
        }
    }

    public void saveClusterFile(String fileName, ClusterManager clusterManager) {
        saveClusterFile(null, fileName, clusterManager);
    }

    public void saveClusterFile(String userName, String fileName, ClusterManager clusterManager) {
        int listSize = clusterManager.getClusterSize();

        File outputFile = getOutputFileName(fileName, userName);
        try {
            int counter = 0;
            fstream = new FileWriter(outputFile);
            BufferedWriter out = new BufferedWriter(fstream);
            while (true) {
                out.write(clusterManager.getClusterForSaveAt(counter));
                counter++;
                if (counter >= listSize)
                    break;
            }
            out.close();
        } catch (IOException e) {
            System.err.println("Error:" + e.getMessage());
        }
    }

    private File getOutputFileName(String fileName, String userName) {
        if (fileName.isEmpty()) {
            return new File(DEFAULT_OUTPUT_FILE);
        }
        if (!fileName.contains(OUTPUT_FILE_SUFFIX)) {
            fileName = fileName.concat(OUTPUT_FILE_SUFFIX);
        }
        if(userName != null) {
            String pathToFile = "users"+ File.separator + userName + File.separator;
            fileName = pathToFile + fileName;
            File test = new File(pathToFile);
            new File(test.getAbsolutePath()).mkdir();
            System.out.println("pathtoFile: " + fileName);
        }
        return new File(fileName);
    }

    public void saveCurrentFile(String name) {
        int listSize = main.getWordTagListSize() - 1;
        if (name.equals("")) {
            name = "ajutine.txt";
        }
        if (!name.contains(".txt")) {
            name.concat(".txt");
        }
        try {
            int counter = 0;
            fstream = new FileWriter(name);
            BufferedWriter out = new BufferedWriter(fstream);
            while (true) {
                counter++;
                out.write(main.getWordTagToSave(counter));
                //System.out.println("suurus praegu " + main.getWordTagListSize());
                if (counter >= listSize)
                    break;
            }
            out.close();
        } catch (IOException e) {
            System.err.println("Error:" + e.getMessage());
        }
    }

    public String loadSelectedFile(String name) {
        File file = new File(name);
        StringBuffer contents = new StringBuffer();
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String text = null;
            while ((text = reader.readLine()) != null) {
                if (!text.startsWith(" ")) {
                    contents.append("-----" + text).append(System.getProperty("line.separator"));
                } else {
                    contents.append(text).append(System.getProperty("line.separator"));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return contents.toString();
    }

    public void loadSelectedFileWithNoInMemoryArray(String name) {
        File file = new File(name);
        BufferedReader reader = null;
        String extractLine = "";
        try {
            reader = new BufferedReader(new FileReader(file));
            String text = null;
            while ((text = reader.readLine()) != null) {
                if (!text.startsWith(" ") && !extractLine.isEmpty()) {
                    WordTags wordTags = new WordTags(extractLine, "new");
                    wordTagExtractor.addToAllWordTags(wordTags);
                    extractLine = "";
                }
                extractLine += text + System.getProperty("line.separator");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public String loadFile() {
        File file = new File("test.txt");
        StringBuffer contents = new StringBuffer();
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String text = null;
            while ((text = reader.readLine()) != null) {
                if (!text.startsWith(" ")) {
                    contents.append("-----" + text).append(System.getProperty("line.separator"));
                } else {
                    contents.append(text).append(System.getProperty("line.separator"));
                }
                //System.out.println(text);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        //System.out.println(contents.toString());
        return contents.toString();
    }

    public void setWordTagExtractor(WordTagExtractor wordTagExtractor) {
        this.wordTagExtractor = wordTagExtractor;
    }
}
