package ee.clusters;

public class AnalyzerSettings {
    public boolean morphologicalTags = false;
    public boolean syntacticalTags = false;
    public boolean punctuation = false;
    public int clusterSize = 3;
    public boolean wordTagAnalysis = false;

    public AnalyzerSettings analyzeMorphologicalTags() {
        morphologicalTags = true;
        return this;
    }

    public AnalyzerSettings analyzeSyntacticalTags() {
        syntacticalTags = true;
        return this;
    }

    public AnalyzerSettings analyzePunctuationTags() {
        punctuation = true;
        return this;
    }

    public AnalyzerSettings analyzeWordTags() {
        wordTagAnalysis = true;
        return this;
    }

    public boolean[] getAsOldSettingFormat() {
        return new boolean[]{morphologicalTags, syntacticalTags, punctuation};
    }

    public int getClusterSize() {
        return clusterSize;
    }

    public void setClusterSize(int clusterSize) {
        this.clusterSize = clusterSize;
    }
}
