package ee.clusters;

import ee.words.WordTag;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.util.ArrayList;

public class SyntacticCluster extends Cluster {

    public SyntacticCluster(ArrayList<WordTag> input, int clusterSize) {
        super(input, clusterSize);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 31).
                append(getClusterId()).
                toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof SyntacticCluster))
            return false;
        if (obj == this)
            return true;

        SyntacticCluster rhs = (SyntacticCluster) obj;
        return new EqualsBuilder().append(getClusterId(), rhs.getClusterId()).isEquals();
    }

    @Override
    public String getClusterId() {
        String toReturn = "";
        for (WordTag word : wordTags)
            toReturn += word.getSyntacticTag();
        return toReturn;
    }
}
