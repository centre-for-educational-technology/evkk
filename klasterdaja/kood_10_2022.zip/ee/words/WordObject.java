package ee.words;

public class WordObject {
  public String word;
  public String morphologicalTag;
  public String syntacticTag;

  public String toString(){
    return word + " "+morphologicalTag+" "+syntacticTag;
  }
}