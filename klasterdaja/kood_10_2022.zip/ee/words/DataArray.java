package ee.words;

import java.util.Arrays;

public class DataArray {
    String[][] wordTag;
    String[][][] textWithTags;


    public DataArray() {


    }

    public String[][] extractWordTag(String wordTags) {
        String[][] wordTagArray = new String[3][10];
        //wordTagArray[0][0]="tere";
        String[] temp = wordTags.split("//");
        wordTagArray[0] = temp[0].split(" ");
        wordTagArray[1] = temp[1].split(" ");
        wordTagArray[2] = temp[2].split(" ");
        System.out.println(Arrays.toString(wordTagArray[0]));
        return wordTagArray;
    }

}
