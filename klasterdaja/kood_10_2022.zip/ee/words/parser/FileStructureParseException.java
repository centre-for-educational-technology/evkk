package ee.words.parser;

public class FileStructureParseException extends Throwable {
  public FileStructureParseException(String message) {
    super(message);
  }
}
