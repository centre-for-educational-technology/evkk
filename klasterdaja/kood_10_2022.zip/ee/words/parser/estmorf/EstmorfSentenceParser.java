package ee.words.parser.estmorf;

import ee.words.parser.SentenceParser;

public class EstmorfSentenceParser extends SentenceParser {

  public EstmorfSentenceParser() {
    super(new EstmorfWordParser());
  }

}
