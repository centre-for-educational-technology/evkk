package ee.words.parser.estmorf;

import ee.words.parser.FileParser;

public class EstmorfParser extends FileParser {

  public EstmorfParser() {
    super(new EstmorfSentenceParser());
  }
}
