package ee.words.parser;

import ee.words.WordObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public abstract class SentenceParser {
  public static final String ELEMENT_START_PREFIX = "\"<";
  public static final String ELEMENT_START_SUFFIX = ">\"";
  protected String SENTENCE_START_TAG = "\"<s>\"";
  protected String SENTENCE_END_TAG = "\"</s>\"";
  protected WordParser wordParser;

  public SentenceParser(WordParser wordParser) {
    this.wordParser = wordParser;
  }

  public List<WordObject> parseAllSentences(BufferedReader reader) throws IOException, FileStructureParseException {
    parseSentenceStart(reader);
    return parseWordsUntilEndOfFile(reader);
  }

  protected void parseSentenceStart(BufferedReader reader) throws IOException, FileStructureParseException {
    String line = reader.readLine();
    while (line != null && line.trim().isEmpty()) {
      line = reader.readLine();
    }
    if (line != null && !startOfSentence(line)) {
      throw new FileStructureParseException("Expected start of sentence with " + SENTENCE_START_TAG);
    }
  }

  protected boolean startOfSentence(String line) {
    return line.trim().equals(SENTENCE_START_TAG);
  }

  protected boolean endOfSentence(String line) {
    return line.trim().equals(SENTENCE_END_TAG);
  }

  protected List<WordObject> parseWordsUntilEndOfFile(BufferedReader reader) throws IOException, FileStructureParseException {
    String line;
    List<WordObject> words = new ArrayList<WordObject>();
    while ((line = reader.readLine()) != null) {
      if (matchesElementStartPattern(line) && !endOfSentence(line)) {
        String nextLine = reader.readLine();
        //if (!nextLine.contains(" Z ")) {
          try {
              words.add(wordParser.parseWordObject(line, nextLine));
          } catch (Exception e) {
              e.printStackTrace();
          }
//        }
      } else if (endOfSentence(line)) {
        parseSentenceStart(reader);
      }
    }
    return words;
  }

  private boolean matchesElementStartPattern(String line) {
    return line.startsWith(ELEMENT_START_PREFIX) && line.endsWith(ELEMENT_START_SUFFIX);
  }

}
