package ee.words.parser;

import ee.words.WordObject;

import java.io.*;
import java.util.List;

public abstract class FileParser {
  private BufferedReader reader;
  private List<WordObject> wordObjects;
  private SentenceParser sentenceParser;

  public FileParser(SentenceParser sentenceParser) {
    this.sentenceParser = sentenceParser;
  }

  public void setFile(File input) throws FileNotFoundException {
    reader = new BufferedReader(new FileReader(input));
  }

  public void parseFile() throws IOException, FileStructureParseException {
    wordObjects = sentenceParser.parseAllSentences(reader);
   // System.out.println(wordObjects); 
  }

  public List<WordObject> getWordObjects() {
    return wordObjects;
  }
}
