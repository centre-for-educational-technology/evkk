package clusters;

import ee.clusters.AnalyzerSettings;
import ee.clusters.ClusterManager;
import ee.filemanagment.FileManager;
import org.junit.*;
import ee.words.WordTagExtractor;

import static org.junit.Assert.assertEquals;

public class ClusterManagerTest {

    public static final String BIG_TEST_FILE = "src/test/resources/70000.txt";
    public static final String SMALL_TEST_FILE = "src/test/resources/2000.txt";

    @Ignore
    @Test
    public void analyze70kWords() throws Exception {
        ClusterManager clusterManager = new ClusterManager();
        WordTagExtractor wordTagExtractor = new WordTagExtractor();
        AnalyzerSettings settings = new AnalyzerSettings();
        FileManager fileManager = new FileManager();
        wordTagExtractor.extractAllWordTags(fileManager.loadSelectedFile(BIG_TEST_FILE).split("-----"));
        clusterManager.setWordTagExtractor(wordTagExtractor);

        clusterManager.getClusters(settings);
        assertEquals("1 ; _S_ com sg nom ; _V_ main indic impf ps3 sg ps af #FinV #NGP-P ; _P_ pos sg gen ; ; pererahvas veetis oma \n", clusterManager.getClusterForSaveAt(2));
    }

    @Ignore
    @Test
    public void analyze70kWordsWithNoInMemoryArray() throws Exception {
        ClusterManager clusterManager = new ClusterManager();
        WordTagExtractor wordTagExtractor = new WordTagExtractor();
        AnalyzerSettings settings = new AnalyzerSettings();
        FileManager fileManager = new FileManager();
        fileManager.setWordTagExtractor(wordTagExtractor);
        fileManager.loadSelectedFileWithNoInMemoryArray(BIG_TEST_FILE);
        clusterManager.setWordTagExtractor(wordTagExtractor);
        //doReturn(wordTagExtractor.getWordTagListSize()).when(clusterManager.mainWindow.getClusterListSize());

        clusterManager.getClusters(settings);
        assertEquals("1 ; _S_ com sg nom ; _V_ main indic impf ps3 sg ps af #FinV #NGP-P ; _P_ pos sg gen ; ; pererahvas veetis oma \n", clusterManager.getClusterForSaveAt(2));
        assertEquals(84, clusterManager.getClusters().getHighestCountCluster());
        assertEquals("84 ; _D_ ; _D_ ; _D_ ; ; justkui �leni puhevile ; algul v�ga ettevaatlikult ; v�hemalt niisama h�sti ; ju �sna p�hjalikult ; �sna p�hjalikult l�bi ; siis �kitselt vait ; seejuures �sna j�medalt ; k�ll juba enam-v�hem ; otsekui lummatult j�rele ; sealt iial isegi ; iial isegi �ra ; viimati ka rohkem ; p�ris l�plikult sisse ; pealegi veel nii ; veel nii kaugel ; siit enam kui ; ette ainult siis ; ega ometi t�esti ; k�ll mitte kunagi ; ka natuke s��dlaslikult ; eriti h�sti v�lja ; juba ammu enam ; miks ka mitte ; ometi   natuke   aegsamini   ; siis   nii   kaua   ; sealt   ka   enam   ; nii   hullusti   ette   ; sealt   alles   siis   ; juba v�ga kaugel ; ka juba ammu ; nii ruttu �le ; sugugi mitte alati ; vaid pealtn�ha t��kindlalt ; vastu t�iesti k�lmalt ; korraga �leni krampi ; k�ll millegip�rast ainult ; kas v�i s�naliselt ; vist nagu pooleldi ; siis k�ll aeg-ajalt ; siis veel �le ; mitte eriti traagiliselt ; v�hemalt mitte nii ; mitte nii pea ; kunagi v�ga ammu ; siis ikka nii ; ikka nii v�ga ; ju t�iesti isemoodi ; ju ka suisa ; ka siis j�rele ; v�ib-olla ka enne ; siiski �pris harva ; millegip�rast ka p�sti ; otsa nagu iseenesest ; v�ga h�sti ka ; k�ll �ksnes purjusp�i ; teinekord v�ga otsustavalt ; v�ga otsustavalt vahele ; samuti t�iesti reaalselt ; juba   kord   seljataga   ; kohe   kas   v�i   ; siit   samuti   �les-alla   ; siia   n��d   sisse   ; l�busalt   edasi-tagasi   �les-alla   ; kuskile   mujale   ju   ; siin   k�ige   enam   ; kuhu   siis   veel   ; seal   l�puks   l�bi   ; siin   ju   ometi   ; vist alles siis ; alles siis t�is ; siis p�ris �ksi ; ees h�davaevalt l�bi ; pisut hiljem k�ll ; kui palju tahes ; palju tahes �lestikku ; kuidas kiiremini edasi ; j�lle kord �lem��ra ; tegelikult �ldsegi mitte ; veel kord asjatult ; sinna nii pidevalt ; siia kenasti �ra ; veel siin l�hedal ; siis   j�lle   tagasi   ; kas   v�i   natukene   \n", clusterManager.getClusters().getHighestCountClusterWords());
    }

    @Ignore
    @Test
    public void analyze2kWords() throws Exception {
        ClusterManager clusterManager = new ClusterManager();
        WordTagExtractor wordTagExtractor = new WordTagExtractor();
        AnalyzerSettings settings = new AnalyzerSettings().analyzeMorphologicalTags();
        FileManager fileManager = new FileManager();
        wordTagExtractor.extractAllWordTags(fileManager.loadSelectedFile(BIG_TEST_FILE).split("-----"));
        clusterManager.setWordTagExtractor(wordTagExtractor);
        //doReturn(wordTagExtractor.getWordTagListSize()).when(clusterManager.mainWindow.getClusterListSize());

        clusterManager.getClusters(settings);
        assertEquals("1 ; _S_ com sg nom ; _V_ main indic impf ps3 sg ps af #FinV #NGP-P ; _P_ pos sg gen ; ; pererahvas veetis oma \n", clusterManager.getClusterForSaveAt(2));
        assertEquals(3, clusterManager.getClusters().getHighestCountCluster());
        assertEquals("3 ; _D_ ; _A_ pos sg nom ; _S_ com sg nom ; ; igati tore poiss ; ju kirjeldamatu vahe ; �ksnes maskuliinne seltskond \n", clusterManager.getClusters().getHighestCountClusterWords());
    }


    @Ignore
    @Test
    public void analyze2kWordsWithNoInMemoryArray() throws Exception {
        ClusterManager clusterManager = new ClusterManager();
        WordTagExtractor wordTagExtractor = new WordTagExtractor();
        AnalyzerSettings settings = new AnalyzerSettings().analyzeMorphologicalTags();
        FileManager fileManager = new FileManager();
        fileManager.setWordTagExtractor(wordTagExtractor);
        //wordTagExtractor.extractAllWordTags(fileManager.loadSelectedFileWithNoInMemoryArray("2000.txt"));
        fileManager.loadSelectedFileWithNoInMemoryArray(SMALL_TEST_FILE);
        clusterManager.setWordTagExtractor(wordTagExtractor);
        //doReturn(wordTagExtractor.getWordTagListSize()).when(clusterManager.mainWindow.getClusterListSize());

        clusterManager.getClusters(settings);
        assertEquals("1 ; _S_ com sg nom ; _V_ main indic impf ps3 sg ps af #FinV #NGP-P ; _P_ pos sg gen ; ; pererahvas veetis oma \n", clusterManager.getClusterForSaveAt(2));
        assertEquals(3, clusterManager.getClusters().getHighestCountCluster());
        assertEquals("3 ; _D_ ; _A_ pos sg nom ; _S_ com sg nom ; ; igati tore poiss ; ju kirjeldamatu vahe ; �ksnes maskuliinne seltskond \n", clusterManager.getClusters().getHighestCountClusterWords());
    }

}