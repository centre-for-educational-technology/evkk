package ee.clusters;

import ee.words.WordTag;
import junit.framework.Assert;
import org.junit.Test;

import java.util.ArrayList;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ClusterTest {

    @Test
    public void getClusterHasmapId() throws Exception {
        ArrayList<WordTag> wordTags = createWordTags();

        Cluster cluster = new Cluster(wordTags, 3);

        Assert.assertEquals(cluster.getClusterId(), "word1_Mtag%¤:!ä||word1_Stag%¤:!äword2_Mmhae||word2_Stag%¤:!äword3_Mfweh||word3_Stag%¤:!ä");
    }

    @Test
    public void checkIfClusterExists() throws Exception {
        ArrayList<WordTag> wordTags = createWordTags();

        Cluster cluster = new Cluster(wordTags,3);
        Cluster cluster2 = new Cluster(wordTags, 3);

        Assert.assertEquals(cluster.checkIfExists(cluster2, true, true), true);
        Assert.assertEquals(cluster.checkIfExists(cluster2, false, true), true);
        Assert.assertEquals(cluster.checkIfExists(cluster2, true, false), true);
        Assert.assertEquals(cluster.checkIfExists(cluster2, false, false), true);
    }

    private ArrayList<WordTag> createWordTags(){
        WordTag wordTag1 = mock(WordTag.class);
        WordTag wordTag2 = mock(WordTag.class);
        WordTag wordTag3 = mock(WordTag.class);

        when(wordTag1.getMorphologicalTag()).thenReturn("word1_Mtag%¤:!ä");
        when(wordTag1.getSyntacticTag()).thenReturn("word1_Stag%¤:!ä");
        when(wordTag2.getMorphologicalTag()).thenReturn("word2_Mmhae");
        when(wordTag2.getSyntacticTag()).thenReturn("word2_Stag%¤:!ä");
        when(wordTag3.getMorphologicalTag()).thenReturn("word3_Mfweh");
        when(wordTag3.getSyntacticTag()).thenReturn("word3_Stag%¤:!ä");

        ArrayList<WordTag> wordTags = new ArrayList<WordTag>();
        wordTags.add(wordTag1);
        wordTags.add(wordTag2);
        wordTags.add(wordTag3);
        return wordTags;
    }
}
