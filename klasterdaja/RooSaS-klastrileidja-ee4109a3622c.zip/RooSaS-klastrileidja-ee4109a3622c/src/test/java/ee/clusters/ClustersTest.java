package ee.clusters;

import ee.words.WordTag;
import ee.words.WordTags;
import junit.framework.Assert;
import org.junit.Test;

import java.util.ArrayList;

public class ClustersTest {

    public static final int CLUSTER_SIZE = 3;

    @Test
    public void addingClusterShouldAddToRightPlace() throws Exception {
        WordTags wordTagsfull = new WordTags("kasutada\n" +
                "    kasuta+da //_V_ main inf #Part-P //  @-FMV @SUBJ +@ADVL ## 0\n" +
                "oli\n" +
                "    ole+i //_V_ main indic impf ps3 sg ps af #FinV #Intr //  @+FMV ## 0\n" +
                "korter\n" +
                "    korter+0 //_S_ com sg nom //  +@SUBJ @OBJ  ## 0", "new");

        WordTags wordTagsfull2 = new WordTags("kasutada\n" +
                "    kasuta+da //_V_ main inf #Part-P //  @-FMV @SUBJ +@ADVL ## 0\n" +
                "oli\n" +
                "    ole+i //_V_ main indic impf ps3 sg ps af #FinV #Intr //  @+FMV ## 0\n" +
                "korter\n" +
                "    korter+0 //_S_ com sg nom //  +@SUBJ @OBJ  ## 0", "new");

        WordTag wordTag = new WordTag("kasutada\n" +
                "    kasuta+da //_V_ main inf #Part-P //  @-FMV @SUBJ +@ADVL ## 0", false, wordTagsfull);
        WordTag wordTag1 = new WordTag("oli\n" +
                "        ole+i //_V_ main indic impf ps3 sg ps af #FinV #Intr //  @+FMV ## 0", false,wordTagsfull);
        WordTag wordTag2 = new WordTag("korter\n" +
                "        korter+0 //_S_ com sg nom //  +@SUBJ @OBJ  ## 0", false, wordTagsfull);

        WordTag wordTag5 = new WordTag("kasutada\n" +
                "    kasuta+da //_V_ main inf #Part-P //  @-FMV @SUBJ +@ADVL ## 0", false, wordTagsfull2);
        WordTag wordTag6 = new WordTag("oli\n" +
                "        ole+i //_V_ main indic impf ps3 sg ps af #FinV #Intr //  @+FMV ## 0", false, wordTagsfull2);
        WordTag wordTag7 = new WordTag("korter\n" +
                "        korter+0 //_S_ com sg nom //  +@SUBJ @OBJ  ## 0", false, wordTagsfull2);


        Clusters clusters = new Clusters();
        ArrayList<WordTag> wordTags =  new ArrayList<WordTag>(3);
        wordTags.add(wordTag);
        wordTags.add(wordTag1);
        wordTags.add(wordTag2);

        ArrayList<WordTag> wordTags2 =  new ArrayList<WordTag>(3);
        wordTags2.add(wordTag5);
        wordTags2.add(wordTag6);
        wordTags2.add(wordTag7);

        AnalyzerSettings settings = new AnalyzerSettings();
        settings.setClusterSize(3);
        settings.morphologicalTags =  true;
        settings.syntacticalTags = true;

        clusters.addCluster(wordTags, settings, CLUSTER_SIZE);
        clusters.addCluster(wordTags2, settings, CLUSTER_SIZE);

        Assert.assertEquals(2, clusters.getHighestCountCluster());
    }


}