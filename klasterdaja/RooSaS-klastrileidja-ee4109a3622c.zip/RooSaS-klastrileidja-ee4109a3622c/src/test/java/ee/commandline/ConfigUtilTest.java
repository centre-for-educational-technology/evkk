package ee.commandline;

import junit.framework.Assert;
import org.apache.commons.cli.MissingArgumentException;
import org.junit.Test;

import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertEquals;

public class ConfigUtilTest {

    @Test(expected = IllegalArgumentException.class)
    public void throwErrorIfNoFileNameInArguments() throws Exception {
        String[] args = {"noArguments"};

        new ConfigUtil(args);
    }

    @Test
    public void doNotThrowErrorIfFileNameInArguments() throws Exception {
        String[] args = {"-f fileName.txt"};

        new ConfigUtil(args);
    }

    @Test (expected = MissingArgumentException.class)
    public void doThrowErrorIfFileNameInArguments() throws Exception {
        String[] args = {"-f"};

        new ConfigUtil(args);
    }

    @Test
    public void shouldParseFileNameWithoutSurroundingSpaces() throws Exception {
        String[] args = {"-f  fileName.txt "};
        ConfigUtil config = new ConfigUtil(args);

        assertEquals("fileName.txt", config.getInputFileName());
    }

    @Test
    public void shouldParseUserNameWithoutSurroundindSpaces() throws Exception {
        String[] args = {"-f fileName.txt", "-u Tom"};
        ConfigUtil config = new ConfigUtil(args);

        assertEquals("Tom", config.getUserName());
    }

    @Test
    public void shouldGetMorphologicalTagsFromCommandline() throws Exception {
        String[] args = {"-f fileName.txt", "-u Tom", "-m"};
        ConfigUtil config = new ConfigUtil(args);

        assertTrue("No such argument morpho", config.isMorphologicalTag());
    }

    @Test
    public void shouldGetSyntacticalTagsFromCommandline() throws Exception {
        String[] args = {"-f fileName.txt", "-u Tom", "-s"};
        ConfigUtil config = new ConfigUtil(args);

        assertTrue("No such argument syntactic", config.isSyntacticalTag());
    }

    @Test
    public void shouldGetPunctuationOptionFromCommandline() throws Exception {
        String[] args = {"-f fileName.txt", "-u Tom", "-z"};
        ConfigUtil config = new ConfigUtil(args);

        assertTrue("No such argument punctuation", config.isPunctuationTag());
    }

    @Test
    public void shouldGetClusterSizeArgumentFromCommandline() throws Exception {
        String[] args = {"-f fileName.txt", "-u Tom", "-z", "-k 2"};
        ConfigUtil config = new ConfigUtil(args);

        assertEquals(2, config.getClusterSize());
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrowExeptionWhenClusterSizeArgumentNotGivenRight() throws Exception {
        String[] args = {"-f fileName.txt", "-u Tom", "-z", "-k asd"};
        ConfigUtil config = new ConfigUtil(args);

        assertEquals(2, config.getClusterSize());
    }

    @Test
    public void shouldBeAbleToAddEstmorfParserArgument() throws Exception {
        String[] args = {"-f fileName.txt", "-u Tom", "-e"};

        ConfigUtil config = new ConfigUtil(args);
        Assert.assertEquals(true, config.isEstmorfParser());
    }
}
