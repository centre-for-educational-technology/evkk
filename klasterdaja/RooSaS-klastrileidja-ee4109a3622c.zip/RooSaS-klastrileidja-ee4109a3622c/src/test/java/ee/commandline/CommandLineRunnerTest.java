package ee.commandline;

import org.junit.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.*;

public class CommandLineRunnerTest {

    public static final String FILE_NAME_ARGUMENT = "2000.txt";
    public static final String BIG_FILE_NAME_ARGUMENT = "70000.txt";
    public static final String USER_NAME_ARGUMENT = "SaS";
    public static final String MORPHOLOGICAL_TAG = "-m";
    public static final String SYNTACTICAL_TAG = "-s";
    public static final String PUNCTUATION_TAG = "-z";
    private static final String CLUSTER_SIZE_ARGUMENT = "2";
    private static final String ESTMORF_TAG = "-e";
    private static final String ESTMORF_FILE_NAME_ARGUMENT = "estmorf.txt";
    private static final String ESTMORF_FILE_NAME_ARGUMENT_SPACE_ERROR = "tyhikuviga.txt";
    private static final String ESTMORF_FILE_NAME_ARGUMENT2 = "estmorf_test.txt";
    private static final String ESTMORF_FILE_NAME_ARGUMENT3 = "estmorf_test2.txt";
    private static final String ESTMORF_FILE_NAME_ARGUMENT4 = "estmorph-text-graphic.txt";
    private static final String ESTMORF_FILE_NAME_BUG_WITH_BASIC_SENTENCE = "morfoanalyzerBug1.txt";
    private static final String WORD_TAGS = "-w";

  ArgumentGenerator argumentGenerator;

    @Before
    public void setUp() throws Exception {
        argumentGenerator = new ArgumentGenerator();
    }

    @Test
    public void analyseFile() throws Exception {
        new CommandLineRunner(argumentGenerator
                .withFileName()
                .build());
        File file = new File(getFullFilePath(FILE_NAME_ARGUMENT));

        FileReader reader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(reader);
        assertEquals("3 ; _D_ ; _A_ pos sg nom ; _S_ com sg nom ; ; igati tore poiss ; ju kirjeldamatu vahe ; �ksnes maskuliinne seltskond ", bufferedReader.readLine());
    }

    @Ignore
    @Test
    public void analyseEstmorfFile() throws Exception {
        new CommandLineRunner(argumentGenerator
                .withEstmorfFileName()
                .withEstmorf()
                .build());
        File file = new File(getFullFilePath(ESTMORF_FILE_NAME_ARGUMENT));

        FileReader reader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(reader);
        assertEquals("3 ; L0 S com sg gen cap; L0 S com sg gen cap; L0 S com sg gen cap; ; Lõuna prefektuuri korrakaitsebüroo ; sõiduki spidomeetri näidu ; spidomeetri näidu filmimise ", bufferedReader.readLine());
    }

    @Test
    public void analyseEstmorfFileSpaceError() throws Exception {
        new CommandLineRunner(argumentGenerator
                .withEstmorfFileNameSpaceError()
                .withEstmorf()
                .build());
    }

    @Ignore
    @Test
    public void analyseEstmorfFile2() throws Exception {
        new CommandLineRunner(argumentGenerator
                .withEstmorfFileName2()
                .withEstmorf()
                .build());
        File file = new File(getFullFilePath(ESTMORF_FILE_NAME_ARGUMENT2));

        FileReader reader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(reader);
        assertEquals("2 ; L0 V main indic pres ps3 sg ps af cap <FinV> <Intr>; L0 D cap; L0 A pos sg nom cap; ; on p�ris mugav ; on seet�ttu kasulik ", bufferedReader.readLine());
    }

    @Ignore
    @Test
    public void analyseEstmorfFile3() throws Exception {
        new CommandLineRunner(argumentGenerator
                .withEstmorfFileName3()
                .withEstmorf()
                .build());
        File file = new File(getFullFilePath(ESTMORF_FILE_NAME_ARGUMENT3));

        FileReader reader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(reader);
        assertEquals("3 ; L0 S prop sg nom cap; Li V main indic impf ps3 sg ps af cap <FinV> <Intr>; L0 S com sg adit cap; ; Juku tuli kooli ; Mati tuli kooli ; Kati tuli kooli ", bufferedReader.readLine());
    }

    @Test
    public void analyseEstmorfFile4() throws Exception {
        new CommandLineRunner(argumentGenerator
                .withEstmorfFileName4()
                .withEstmorf()
                .build());
        File file = new File(getFullFilePath(ESTMORF_FILE_NAME_ARGUMENT4));

        FileReader reader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(reader);
        assertEquals("11 ; L0 S com sg nom cap; L0 S com sg gen cap; L0 S com sg nom; ; import java awt ; import java awt ; import java awt ; import java awt ; import java awt ; import java awt ; import java applet ; import java awt ; import java awt ; import java awt ; import java awt ", bufferedReader.readLine());
    }

    @Test
    public void whenUserIsProvidedFileShouldBeSavedToUserFolder() throws Exception {
        new CommandLineRunner(argumentGenerator
                .withFileName()
                .withUserName()
                .build());
        assertTrue(new File("users" + File.separator + USER_NAME_ARGUMENT + File.separator + FILE_NAME_ARGUMENT.replace(".txt", ".csv")).exists());
    }

    private String getFullFilePath(String filePath) {
        return System.getProperty("user.dir") + File.separator + filePath.replace(".txt", ".csv");
    }

    @Test
    public void setSettingAccordingToCommandlineArguments() throws Exception {
        CommandLineRunner commandLineRunner = new CommandLineRunner(argumentGenerator
                .withFileName()
                .withUserName()
                .withMorphoTag()
                .withPunctuation()
                .withSyntacticTag()
                .build());
        assertTrue(commandLineRunner.getSettings().morphologicalTags);
        assertTrue(commandLineRunner.getSettings().syntacticalTags);
        assertTrue(commandLineRunner.getSettings().punctuation);
    }

    @Test
    public void shouldUseDefaultOptionsWhenNoOptionArgumentGiven() throws Exception {
        CommandLineRunner commandLineRunner = new CommandLineRunner(argumentGenerator
                .withFileName()
                .withUserName()
                .build());

        assertTrue(commandLineRunner.getSettings().morphologicalTags);
    }

    @Test
    public void setSettingAccordingToCommandlineArgumentsIfOnlySyntacticalTags() throws Exception {
        CommandLineRunner commandLineRunner = new CommandLineRunner(argumentGenerator
                .withFileName()
                .withUserName()
                .withSyntacticTag()
                .build());

        assertTrue(commandLineRunner.getSettings().syntacticalTags);
        assertFalse(commandLineRunner.getSettings().morphologicalTags);
    }

    @Test
    public void shouldUseDefaultClusterSizeArgumentIfNoArgumentGivenForCommandline() throws Exception {
        CommandLineRunner commandLineRunner = new CommandLineRunner(argumentGenerator
                .withFileName()
                .withUserName()
                .build());

        assertEquals(3, commandLineRunner.getSettings().clusterSize);
    }

    @Test
    public void testExtractClustersWithWordType() throws Exception {
        new CommandLineRunner(argumentGenerator
            .withFileName()
            .withClusterSize(3)
            .withWordType()
            .build());
        File file = new File(getFullFilePath(FILE_NAME_ARGUMENT));

        FileReader reader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(reader);
        assertEquals("14 ; _V_; _A_; _S_; ; kroonis t�helepanuv��rne n�rkus ; toimub meeldiva naisolevuse ; m��rab kindlaks kunstiteose ; on professionaalne vilumus ; tegid koosveedetud tunnid ; siginema uusi naistuttavaid ; hoidunud petlikest armuavaldustest ; sarnanes saagiahnele �ngemehele ; poleks saunasoe jutul�ng ; on p�hap�evasel p�eval ; tuleb suurem viinav�tmine ; tormab kogu rannas ; olid kogu aeg ; lasksime hilissuvisel p�ikesel ", bufferedReader.readLine());
    }

    @Test
    public void analyseEstmorfFile4WithWordTypes() throws Exception {
        new CommandLineRunner(argumentGenerator
                .withEstmorfFileName4()
                .withEstmorf()
                .withClusterSize(3)
                .withWordType()
                .build());
        File file = new File(getFullFilePath(ESTMORF_FILE_NAME_ARGUMENT4));

        FileReader reader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(reader);
        assertEquals("42 ; _S_; _S_; _S_; ; programmiga pildid valmis ; import java awt ; import java applet ; keeramine Üksühene arvutuskoordinaatide ; y-telje kasvamise suund ; Ekraani y-punkti arvutamisel ; täpp rakendi y-koordinaadile ; import java awt ; import java awt ; java awt geom ; import java awt ; import java applet ; static void main ; import java awt ; import java applet ; static void main ; import java awt ; import java applet ; static void main ; joonise servadesse koordinaadid ; kahekümnendiku arvutuspiirkonna pikkuse ; servadesse koordinaatide joonistamiseks ; arvude suhte täisosa ; arvu kümnendkohtadega ümardamiseks ; Javas vaikimisi kujul ; arv Math pow ; import java applet ; java applet Applet ; import java awt ; import java awt ; java awt event ; public class Graafik5Rakend ; class Graafik5Rakend extends ; Graafik5Rakend extends Applet ; nupp new Button ; public void actionPerformed ; import java awt ; import java awt ; java awt event ; arv Math pow ; public static void ; static void main ", bufferedReader.readLine());
    }


  @Test
    public void testCommandLineRunnerWithClusterSizeParameter() throws Exception {
        new CommandLineRunner(argumentGenerator
                .withFileName()
                .withClusterSize()
                .build());
        File file = new File(getFullFilePath(FILE_NAME_ARGUMENT));

        FileReader reader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(reader);
        assertEquals("11 ; _D_ ; _A_ pos sg nom ; ; vahel meeldiv ; igati tore ; �snagi veider ; ju kirjeldamatu ; �limalt siiras ; v�ga kena ; kuiv�rd kena ; �ksnes maskuliinne ; talutavalt jahe ; lausa uskumatu ; ainult p�lvepikkune ", bufferedReader.readLine());
    }

    @Test
    public void testMorfoanalyzerBugWithNotAccountingForAllWords() throws Exception {
        new CommandLineRunner(argumentGenerator
                .withFileName(ESTMORF_FILE_NAME_BUG_WITH_BASIC_SENTENCE)
                .withClusterSize(3)
                .withEstmorf()
                .build());
        File file = new File(getFullFilePath(ESTMORF_FILE_NAME_BUG_WITH_BASIC_SENTENCE));

        FileReader reader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(reader);
        bufferedReader.readLine();
        assertEquals("1 ; L0 S prop sg nom cap; Li V main indic impf ps3 sg ps af cap <FinV> <Intr>; L0 S com sg adit cap; ; Juku tuli kooli ", bufferedReader.readLine());

    }

    public class ArgumentGenerator{
        private String[] args = new String[0];

        public ArgumentGenerator(){}

        public ArgumentGenerator withFileName(){
            this.addArgument("-f " + FILE_NAME_ARGUMENT);
            return this;
        }

        public ArgumentGenerator withFileName(String fileName){
            this.addArgument("-f " + fileName);
            return this;
        }

        public ArgumentGenerator withHugeFileName(){
            this.addArgument("-f " + BIG_FILE_NAME_ARGUMENT);
            return this;
        }

        public ArgumentGenerator withUserName(){
            this.addArgument("-u " + USER_NAME_ARGUMENT);
            return this;
        }

        public ArgumentGenerator withMorphoTag(){
            this.addArgument(MORPHOLOGICAL_TAG);
            return this;
        }

        public ArgumentGenerator withPunctuation() {
            this.addArgument(PUNCTUATION_TAG);
            return this;
        }

        public ArgumentGenerator withSyntacticTag() {
            this.addArgument(SYNTACTICAL_TAG);
            return this;
        }

        public ArgumentGenerator withEstmorf() {
            this.addArgument(ESTMORF_TAG);
            return this;
        }

        public ArgumentGenerator withClusterSize() {
            this.addArgument("-k " + CLUSTER_SIZE_ARGUMENT);
            return this;
        }

        public ArgumentGenerator withClusterSize(int number) {
            this.addArgument("-k " + number);
            return this;
        }

        public String[] build(){
            return args;
        }

        private void addArgument(String argumentToAdd) {
            List<String> list = new ArrayList<String>();
            for(String arg : args){
                list.add(arg);
            }
            list.add(argumentToAdd);
            args = new String[list.size()];
            list.toArray(args);
        }

        public ArgumentGenerator withEstmorfFileName() {
            this.addArgument("-f " + ESTMORF_FILE_NAME_ARGUMENT);
            return this;
        }
        public ArgumentGenerator withEstmorfFileNameSpaceError() {
            this.addArgument("-f " + ESTMORF_FILE_NAME_ARGUMENT_SPACE_ERROR);
            return this;
        }
        public ArgumentGenerator withEstmorfFileName2() {
            this.addArgument("-f " + ESTMORF_FILE_NAME_ARGUMENT2);
            return this;
        }
        public ArgumentGenerator withEstmorfFileName3() {
            this.addArgument("-f " + ESTMORF_FILE_NAME_ARGUMENT3);
            return this;
        }
        public ArgumentGenerator withEstmorfFileName4() {
            this.addArgument("-f " + ESTMORF_FILE_NAME_ARGUMENT4);
            return this;
        }

        public ArgumentGenerator withWordType() {
            this.addArgument(WORD_TAGS);
            return this;
        }
    }
}
