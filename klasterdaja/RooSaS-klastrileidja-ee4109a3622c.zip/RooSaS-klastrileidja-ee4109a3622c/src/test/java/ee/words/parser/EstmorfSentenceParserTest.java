package ee.words.parser;

import ee.words.parser.estmorf.EstmorfSentenceParser;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.StringReader;

public class EstmorfSentenceParserTest {

  @Test(expected = FileStructureParseException.class)
  public void sentenceNotStartingWithSentenceTagThrowsException() throws Exception, FileStructureParseException {
    BufferedReader reader = new BufferedReader(new StringReader("wrong start of sentence"));
    EstmorfSentenceParser estmorfSentenceParser = new EstmorfSentenceParser();

    estmorfSentenceParser.parseAllSentences(reader);
  }
}
