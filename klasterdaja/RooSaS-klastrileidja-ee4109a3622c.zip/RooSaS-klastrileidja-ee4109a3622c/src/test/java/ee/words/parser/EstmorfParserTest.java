package ee.words.parser;

import ee.words.WordObject;
import ee.words.parser.estmorf.EstmorfParser;
import org.junit.Test;

import java.io.File;
import java.util.List;

import static junit.framework.Assert.assertEquals;

public class EstmorfParserTest {

  @Test
  public void shouldParseFile() throws Exception, FileStructureParseException {
    File file = new File("estmorfTest.txt");
    EstmorfParser parser = new EstmorfParser();
    parser.setFile(file);
    parser.parseFile();
    List<WordObject> result = parser.getWordObjects();

    assertEquals(9, result.size());
    assertThatWordIs(result.get(0), "Tassis", "Ls S com sg in cap", "@ADVL");
    assertThatWordIs(result.get(1), "on", "L0 V main indic pres ps3 sg ps af cap <FinV> <Intr>", "@FMV");
    assertThatWordIs(result.get(2), "roheline", "L0 A pos sg nom cap", "@AN>");
    assertThatWordIs(result.get(3), "tee", "L0 S com sg nom cap", "@SUBJ");

    assertThatWordIs(result.get(4), ".", "Z Fst", "");
    assertThatWordIs(result.get(5), "Tee", "L0 V main imper pres ps2 sg ps af cap <FinV> <NGP-P>", "@FMV");
    assertThatWordIs(result.get(6), "tool", "L0 S com sg nom cap", "@NN> @OBJ");
    assertThatWordIs(result.get(7), "korda", "L0 S com sg part cap", "@OBJ @ADVL");
    assertThatWordIs(result.get(8), "!", "Z Exc", "");
  }

  private void assertThatWordIs(WordObject wordObject, String word, String morph, String synt) {
    assertEquals(word, wordObject.word);
    assertEquals(morph, wordObject.morphologicalTag);
    assertEquals(synt, wordObject.syntacticTag);
  }
}
