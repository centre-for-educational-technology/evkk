package ee.words;

import junit.framework.Assert;
import org.junit.Test;

import static org.mockito.Mockito.mock;

public class WordTagTest {

    @Test
    public void generateWordTags() throws Exception {
        WordTag wordTag = new WordTag("kasutada\n" +
                "    kasuta+da //_V_ main inf #Part-P //  @-FMV @SUBJ +@ADVL ## 0", false, mock(WordTags.class));
        Assert.assertEquals("_V_ main inf #Part-P ", wordTag.getMorphologicalTag());
        Assert.assertEquals("  @-FMV @SUBJ +@ADVL ", wordTag.getSyntacticTag());
    }
}
