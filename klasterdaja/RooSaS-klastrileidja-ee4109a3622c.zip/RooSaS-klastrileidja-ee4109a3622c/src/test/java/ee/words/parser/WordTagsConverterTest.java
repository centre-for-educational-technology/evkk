package ee.words.parser;

import ee.words.WordObject;
import ee.words.WordTagExtractor;
import ee.words.parser.estmorf.EstmorfParser;
import junit.framework.Assert;
import org.junit.Test;

import java.io.File;
import java.util.List;

public class WordTagsConverterTest {

    @Test
    public void testConvertEstmorfToWordTags() throws Exception {
        File file = new File("estmorfTest.txt");
        EstmorfParser parser = new EstmorfParser();
        parser.setFile(file);
        try {
            parser.parseFile();
        } catch (FileStructureParseException e) {
            e.printStackTrace();
        }
        List<WordObject> result = parser.getWordObjects();

        WordTagExtractor wordTagExtractor = new WordTagExtractor();

        wordTagExtractor.extractAllWordTagsFrom(result);

        Assert.assertEquals("Ls S com sg in cap", wordTagExtractor.getWordTagAt(0).getTag().getMorphologicalTag());
        Assert.assertEquals("L0 V main indic pres ps3 sg ps af cap <FinV> <Intr>", wordTagExtractor.getWordTagAt(1).getTag().getMorphologicalTag());
        Assert.assertEquals("L0 A pos sg nom cap", wordTagExtractor.getWordTagAt(2).getTag().getMorphologicalTag());
        Assert.assertEquals("L0 S com sg nom cap", wordTagExtractor.getWordTagAt(3).getTag().getMorphologicalTag());
        Assert.assertEquals("Z Fst", wordTagExtractor.getWordTagAt(4).getTag().getMorphologicalTag());
        Assert.assertEquals("L0 V main imper pres ps2 sg ps af cap <FinV> <NGP-P>", wordTagExtractor.getWordTagAt(5).getTag().getMorphologicalTag());
        Assert.assertEquals("L0 S com sg nom cap", wordTagExtractor.getWordTagAt(6).getTag().getMorphologicalTag());
        Assert.assertEquals("L0 S com sg part cap", wordTagExtractor.getWordTagAt(7).getTag().getMorphologicalTag());
        Assert.assertEquals("Z Exc", wordTagExtractor.getWordTagAt(8).getTag().getMorphologicalTag());

        Assert.assertEquals("Tassis", wordTagExtractor.getWordTagAt(0).getTag().getName());
        Assert.assertEquals("on", wordTagExtractor.getWordTagAt(1).getTag().getName());
        Assert.assertEquals("roheline", wordTagExtractor.getWordTagAt(2).getTag().getName());
        Assert.assertEquals("tee", wordTagExtractor.getWordTagAt(3).getTag().getName());
        Assert.assertEquals(".", wordTagExtractor.getWordTagAt(4).getTag().getName());
        Assert.assertEquals("Tee", wordTagExtractor.getWordTagAt(5).getTag().getName());
        Assert.assertEquals("tool", wordTagExtractor.getWordTagAt(6).getTag().getName());
        Assert.assertEquals("korda", wordTagExtractor.getWordTagAt(7).getTag().getName());
        Assert.assertEquals("!", wordTagExtractor.getWordTagAt(8).getTag().getName());

        Assert.assertEquals("@ADVL", wordTagExtractor.getWordTagAt(0).getTag().getSyntacticTag());
        Assert.assertEquals("@FMV", wordTagExtractor.getWordTagAt(1).getTag().getSyntacticTag());
        Assert.assertEquals("@AN>", wordTagExtractor.getWordTagAt(2).getTag().getSyntacticTag());
        Assert.assertEquals("@SUBJ", wordTagExtractor.getWordTagAt(3).getTag().getSyntacticTag());
        Assert.assertEquals("", wordTagExtractor.getWordTagAt(4).getTag().getSyntacticTag());
        Assert.assertEquals("@FMV", wordTagExtractor.getWordTagAt(5).getTag().getSyntacticTag());
        Assert.assertEquals("@NN> @OBJ", wordTagExtractor.getWordTagAt(6).getTag().getSyntacticTag());
        Assert.assertEquals("@OBJ @ADVL", wordTagExtractor.getWordTagAt(7).getTag().getSyntacticTag());
        Assert.assertEquals("", wordTagExtractor.getWordTagAt(8).getTag().getSyntacticTag());

    }
}
