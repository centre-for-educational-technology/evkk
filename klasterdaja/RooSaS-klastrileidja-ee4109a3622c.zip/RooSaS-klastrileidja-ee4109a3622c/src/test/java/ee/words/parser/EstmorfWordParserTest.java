package ee.words.parser;

import ee.words.parser.estmorf.EstmorfWordParser;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class EstmorfWordParserTest {
    String line1 = "\"<Tassis>\"";
    String line2 = "        \"tass\" Ls S com sg in cap @ADVL #1->2";
    String sentanceStopLine1 = "\"<.>\"";
    String sentanceStopLine2 = "        \".\" Z Fst #5->5";
    EstmorfWordParser parser;

    @Before
    public void setUp() throws Exception {
        parser = new EstmorfWordParser();
    }

    @Test
    public void shouldParseWord() throws Exception {
        Assert.assertEquals(parser.parseWord(line1), "Tassis");
    }

    @Test
    public void shouldParseMorphoTag() throws Exception {
        Assert.assertEquals(parser.parseMorphologicalTag(line2), "Ls S com sg in cap");
    }

    @Test
    public void shouldParseSyntacticTag() throws Exception {
        Assert.assertEquals(parser.parseSyntacticTag(line2), "@ADVL");
    }

    @Test
    public void shouldParseSentanceStopMark() throws Exception {
        Assert.assertEquals(parser.parseWord(sentanceStopLine1), ".");
    }

    @Test
    public void shouldParseSentanceStopMorphoTag() throws Exception {
        Assert.assertEquals(parser.parseMorphologicalTag(sentanceStopLine2), "Z Fst");
    }

    @Test
    public void shouldParseSentanceStopSyntacticTag() throws Exception {
        Assert.assertEquals(parser.parseSyntacticTag(sentanceStopLine2), "");
    }
}
