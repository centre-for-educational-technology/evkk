package ee.ui;

import ee.commandline.CommandLineRunner;
import org.apache.commons.cli.ParseException;

public class Main {

    public static void main(String[] args) throws ParseException {
        if (args.length < 1) {
            new MainWindow();
        } else {
            new CommandLineRunner(args);
        }
    }

}
