package ee.ui;

import ee.clusters.AnalyzerSettings;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Options extends JDialog {
    MainWindow mainWindow;
    AnalyzerSettings settings = new AnalyzerSettings();
    JLabel searchWithLabel = new JLabel("Klastrite otsimise alus");
    JLabel searchWithMorphLabel = new JLabel("Morfoloogiline");
    JLabel searchWithSyntLabel = new JLabel("Süntaktiline");
    JLabel _Z_Label = new JLabel("Lülita '_Z_' märgendid sisse");
    JLabel clusterSize = new JLabel("Klastri suurus");
    JTextField clusterSizeText = new JTextField();
    JCheckBox _Z_CheckBox = new JCheckBox();
    JCheckBox searchWithMorph = new JCheckBox();
    JCheckBox searchWithSynt = new JCheckBox();


    public Options(JFrame frame, final MainWindow mainWindow) {
        super(frame, "Valikud", true);
        this.mainWindow = mainWindow;
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2));

        panel.add(searchWithLabel);
        panel.add(new JLabel());
        panel.add(searchWithMorphLabel);
        panel.add(searchWithMorph);
        panel.add(searchWithSyntLabel);
        panel.add(searchWithSynt);
        panel.add(_Z_Label);
        panel.add(_Z_CheckBox);
        panel.add(clusterSize);
        panel.add(clusterSizeText);
        JButton ok = new JButton("Otsi");
        panel.add(ok);

        loadSettings();

        getContentPane().add(panel);

        ok.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Save to options todo
                gatherSettings();
                Options.this.mainWindow.analyzeClusters(settings);
                setVisible(false);
            }
        });
        setSize(350, 200);
    }

    public void loadSettings() {
        clusterSizeText.setText(settings.getClusterSize() + "");
        searchWithMorph.setSelected(settings.morphologicalTags);
        searchWithSynt.setSelected(settings.syntacticalTags);
        _Z_CheckBox.setSelected(settings.punctuation);
    }

    public void gatherSettings() {
        try {
            settings.setClusterSize(Integer.parseInt(clusterSizeText.getText()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        settings.morphologicalTags = searchWithMorph.isSelected();
        settings.syntacticalTags = searchWithSynt.isSelected();
        settings.punctuation = _Z_CheckBox.isSelected();
    }

}
