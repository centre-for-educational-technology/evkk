package ee.ui;

import ee.words.WordTag;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

class TableRowRender extends DefaultTableCellRenderer {
    String val;
    MainWindow mainWindow;

    public TableRowRender(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
        setOpaque(true);
    }

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        if (value instanceof JLabel) {
            ((DefaultTableCellRenderer) value).setBackground(Color.red);
            return (JLabel) value;
        }
        if (value != null) {
            val = value.toString();
            if (val.startsWith(" ")) {
            }
        }
        if (mainWindow.getTableRowColor(row) == 0) {
            setBackground(Color.LIGHT_GRAY);
        } else if (mainWindow.getTableRowColor(row) == 1) {
            setBackground(Color.white);
        } else if (mainWindow.getTableRowColor(row) == 2) {
            setBackground(Color.white);
        } else if (mainWindow.getTableRowColor(row) == 3) {
            setBackground(Color.green);
        }
        /*
		else{
			setBackground(Color.white);
		}*/
        setText(value != null ? value.toString() : "");
        if (hasFocus && isSelected && mainWindow.getWordTagAccordingToTableRow(row) != null) {
            WordTag wt = mainWindow.getWordTagAccordingToTableRow(row);
            wt.setNewTags(value.toString());
            System.out.println(row + " " + mainWindow.getWordTagAccordingToTableRow(row).getMorphologicalTag());
        }
        return this;
    }

} 