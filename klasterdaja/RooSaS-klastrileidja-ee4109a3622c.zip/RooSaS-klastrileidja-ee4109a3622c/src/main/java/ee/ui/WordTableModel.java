package ee.ui;

import ee.words.WordTagExtractor;

import javax.swing.table.DefaultTableModel;

public class WordTableModel extends DefaultTableModel {
    WordTagExtractor wordTagExtractor;

    public WordTableModel(WordTagExtractor wordTagExtractor) {
        super();
        this.wordTagExtractor = wordTagExtractor;
    }

    public Class<?> getColumnClass(int column) {
        if (column == 2) {
            return Boolean.class;
        } else {
            return Object.class;
        }
    }

    public boolean isCellEditable(int rowIndex, int mColIndex) {
        if (mColIndex == 1) {
            wordTagExtractor.setWordTagAccordingToTableRow(rowIndex, true);
            //fireTableDataChanged();
            return false;
        }
        return true;
    }

}
