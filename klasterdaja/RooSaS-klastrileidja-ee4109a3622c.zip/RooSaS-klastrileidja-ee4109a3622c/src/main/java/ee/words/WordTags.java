package ee.words;

import ee.ui.MainWindow;

import java.util.ArrayList;

public class WordTags {

    String input;
    ArrayList<WordTag> individualWordTags = new ArrayList<WordTag>();
    MainWindow mainWindow;
    int isSelected = 1;

    public WordTags(WordObject wordObject) {
        WordTag firstWordTag = new WordTag(wordObject.word, this);
        individualWordTags.add(firstWordTag);
        WordTag secondWordTag = new WordTag(wordObject.morphologicalTag, wordObject.syntacticTag, this);
        individualWordTags.add(secondWordTag);
    }

    public WordTags(String input, String type) {
        this.input = input;
        for (int i = 0; i < input.split("\n").length; i++) {
            WordTag wordTag;
            if (i == 0) {
                wordTag = new WordTag(input.split("\n")[i], true, this);
            } else {
                wordTag = new WordTag(input.split("\n")[i], false, this);
                if (type.equals("load")) {
                    try {
                        if (input.split("\n")[i].split("##")[1].replaceAll("\\r", "").equals(" 1")) {
                            isSelected = i;
                        }
                    } catch (Exception e) {
                        System.out.println("error :" + e);
                    }
                }
            }
            individualWordTags.add(wordTag);
        }

        if (type.equals("new")) {
            if (individualWordTags.size() > 2) {
                isSelected = 1;
                individualWordTags.get(isSelected).setSelected();
            }
        } else if (type.equals("load")) {
            if (individualWordTags.size() > 2)
                individualWordTags.get(isSelected).setSelected();
        }

    }

    public String getWordTagsToSave() {
        String toReturn = "";
        for (WordTag wordTag : individualWordTags)
            toReturn += wordTag.getWordTagToSave() + "\n";
        return toReturn;
    }

    public String getName() {
        return individualWordTags.get(0).getNameAsString();
    }

    public WordTag getTag() {
        //System.out.println("Valitud on : " + isSelected + " suurus on : " + individualWordTags.size());
        if (isSelected < individualWordTags.size()) {
            return individualWordTags.get(isSelected);
        }
        return individualWordTags.get(0);
    }

    public void setSelected(int isSelected) {
        int i = 0;
        for (WordTag wordTag : individualWordTags) {
            if (i != individualWordTags.size()) {
                if (isSelected == i) {
                    //System.out.println(wordTag.isSelected +", Ts�kli sees i = " + i );
                    wordTag.setSelected();
                } else {
                    wordTag.setDeselected();
                }
            }
            i++;
        }
        mainWindow.updateTable();
    }

    public boolean isThereMoreThanOneWordTag() {
        return individualWordTags.size() > 2;
    }

    public void setWordTypes() {
        for (WordTag wordTag : individualWordTags) {
            wordTag.setType(Util.TagType.wordWithTags);
        }
        individualWordTags.get(0).setType(Util.TagType.word);
    }


    public void addToTable(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
        for (WordTag word : individualWordTags) {
            mainWindow.addLineToTable(wordTagsToTable(word));
        }

        Object[] toAddToTable = new Object[4];
    }

    public Object[] wordTagsToTable(WordTag word) {
        Object[] toReturn;
        toReturn = word.getWordTags();
        if (!isThereMoreThanOneWordTag()) {
            toReturn[1] = null;
        }
        return toReturn;
    }

}