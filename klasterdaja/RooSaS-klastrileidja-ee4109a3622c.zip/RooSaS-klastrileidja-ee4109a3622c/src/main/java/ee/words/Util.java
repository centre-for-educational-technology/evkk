package ee.words;

public class Util {
	enum TagType{word, wordWithTags}
    enum VerbType{aux, mod, main}
    enum VerbSpeech{indie, cond, imper, quot}
    enum VerbTime{pres, impf, past}
    enum VerbSubject{ps1, ps2, ps3}
    enum VerbNumber{sg, pl}
    enum VerbStyle{ps, imps}
    enum VerbAccent{af, neg}
}
