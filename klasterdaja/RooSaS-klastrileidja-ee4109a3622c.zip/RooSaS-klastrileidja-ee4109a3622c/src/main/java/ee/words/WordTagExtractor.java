package ee.words;

import java.util.ArrayList;
import java.util.List;


public class WordTagExtractor {
    ArrayList<WordTags> allWordTags = new ArrayList<WordTags>();

    public WordTagExtractor() {

    }

    public void extractAllWordTags(String[] extractArray) {
        for (int i = 1; i < extractArray.length; i++) {
            WordTags wordTags = new WordTags(extractArray[i], "new");
            allWordTags.add(wordTags);
        }
    }

    public void extractAllWordTagsFrom(List<WordObject> wordsWithTags){
        for(WordObject wordObject : wordsWithTags) {
            WordTags wordTags = new WordTags(wordObject);
            allWordTags.add(wordTags);
        }
    }

    public void clearAllWordTags() {
        allWordTags.clear();
    }

    public void loadWordTags(String[] extractArray) {
        for (String anExtractArray : extractArray) {
            WordTags wordTags = new WordTags(anExtractArray, "load");
            allWordTags.add(wordTags);
        }
    }

    public String getWordTagsToSave(int counter) {
        return allWordTags.get(counter).getWordTagsToSave();
    }

    public ArrayList<WordTags> getAllWordTags() {
        return allWordTags;
    }

    public WordTags getWordTagAt(int input) {
        return allWordTags.get(input);
    }

    public int getWordTagListSize() {
        return allWordTags.size();
    }

    public WordTag getWordTagAccordingToTableRow(int row) {
        int counter = 0;
        for (WordTags wordTags : allWordTags) {
            for (WordTag wordTag : wordTags.individualWordTags) {
                if (row == counter)
                    return wordTag;
                counter++;
            }
        }
        return null;
    }

    public void setWordTagAccordingToTableRow(int row, boolean select) {
        int counter = 0;
        for (WordTags wordTags : allWordTags) {
            wordTags.setWordTypes();
            int j = 0;
            for (WordTag wordTag : wordTags.individualWordTags) {
                if (j != 0) {
                    if (counter == row) {
                        if (select) {
                            System.out.println("setselected peaks n��d olema " + j);
                            wordTags.setSelected(j);
                        }
                    }
                }
                counter++;
                j++;
            }
        }
    }

    public int[] updateColorTable(int[] tableRowColor) {
        int i = 0;
        for (WordTags wordTags : allWordTags) {
            int j = 0;
            wordTags.setWordTypes();
            for (WordTag wordTag : wordTags.individualWordTags) {
                if (wordTag.getTagType().equals(Util.TagType.wordWithTags)) {
                    tableRowColor[i] = 1;
                } else {
                    tableRowColor[i] = 0;
                }
                if (wordTags.isThereMoreThanOneWordTag()) {
                    tableRowColor[i] = wordTag.getTagColor();
                }
                //System.out.println(wordTag.getWordTags().toString());
                i++;
                j++;
            }
        }
        return tableRowColor;
    }

    public int[] fillColorTable() {
        int[] tableRowColor = new int[getWordTagListSize() * 4];
        int i = 0;
        for (WordTags wordTags : allWordTags) {
            int j = 0;
            wordTags.setWordTypes();
            for (WordTag wordTag : wordTags.individualWordTags) {
                if (wordTag.getTagType().equals(Util.TagType.wordWithTags)) {
                    tableRowColor[i] = 1;
                } else {
                    tableRowColor[i] = 0;
                }
                if (wordTags.isThereMoreThanOneWordTag()) {
                    tableRowColor[i] = wordTag.getTagColor();
                }
                i++;
                j++;
            }
        }
        return tableRowColor;
    }

    public ArrayList<WordTag> getWordTagsForCluster(int size, int count) {
        ArrayList<WordTag> toReturn = new ArrayList<WordTag>(size);
        int allWordTagSize = allWordTags.size();
        for (int i = 0; i < size; i++) {
            if ((count + i) < allWordTagSize) {
                toReturn.add(allWordTags.get(count + i).getTag());
            } else {
            }
        }

        return toReturn;
    }

    public void addToAllWordTags(WordTags input) {
        allWordTags.add(input);
    }
}
