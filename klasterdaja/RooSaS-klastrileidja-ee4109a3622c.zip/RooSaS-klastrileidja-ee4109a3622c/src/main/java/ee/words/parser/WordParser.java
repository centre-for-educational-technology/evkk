package ee.words.parser;

import ee.words.WordObject;

public abstract class WordParser {
    public static final String ELEMENT_START_PREFIX = "\"<";
    public static final String ELEMENT_START_SUFFIX = ">\"";

    public WordObject parseWordObject(String... lines){
        WordObject result = new WordObject();
        result.word = parseWord(lines[0]);
        if (parsedWord(lines[1])) {
            try {
                result.morphologicalTag = parseMorphologicalTag(lines[1]);
                result.syntacticTag = parseSyntacticTag(lines[1]);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            result.morphologicalTag = "noMorphTag";
            result.syntacticTag = "noSyntTag";
        }
        return result;
    }

    protected String parseWord(String line) {
        return line.replace(ELEMENT_START_PREFIX, "").replace(ELEMENT_START_SUFFIX, "");
    }

    protected String parseMorphologicalTag(String line) {
        return line;
    }

    protected String parseSyntacticTag(String line) {
        return line;
    }

    protected boolean parsedWord(String tags) {
        if (tags.startsWith("\"<")) {
            return false;
        }
        return true;
    }
}
