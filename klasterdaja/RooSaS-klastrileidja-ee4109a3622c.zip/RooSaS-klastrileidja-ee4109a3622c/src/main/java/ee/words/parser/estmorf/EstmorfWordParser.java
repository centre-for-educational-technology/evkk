package ee.words.parser.estmorf;

import ee.words.parser.WordParser;

public class EstmorfWordParser extends WordParser {
    public static final String START_OF_SYNT_ELEMENT = "@";
    public static final char WORD_WRAPPER = '"';

    @Override
    public String parseMorphologicalTag(String line) {
        int startOfSecondWordElement = line.indexOf(WORD_WRAPPER, 1);
        int endOfSecondWordElement = line.indexOf(WORD_WRAPPER, startOfSecondWordElement + 1);
        int startOfSyntacticElement = line.indexOf(START_OF_SYNT_ELEMENT);
        if(startOfSyntacticElement == -1){
            int startOfWordIndex = line.indexOf('#');
            if(startOfWordIndex == -1){return "";}
            return line.subSequence(endOfSecondWordElement + 1, startOfWordIndex).toString().trim();
        }
        return line.subSequence(endOfSecondWordElement + 1, startOfSyntacticElement).toString().trim();
    }

    @Override
    public String parseSyntacticTag(String line) {
        int startOfSyntacticElement = line.indexOf(START_OF_SYNT_ELEMENT);
        if(startOfSyntacticElement == -1){
            return "";
        }
        int startOfWordIndex = line.indexOf('#');
        if(startOfWordIndex < 0){
            startOfWordIndex = line.length();
        }
        return line.subSequence(startOfSyntacticElement, startOfWordIndex).toString().trim();
    }
}
