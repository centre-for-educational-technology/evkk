package ee.words;

public enum WordType {
    _V_, _S_, _A_, _G_, _P_, _D_, _K_,
    _J_, _N_, _I_, _Y_, _X_, _Z_;
}
