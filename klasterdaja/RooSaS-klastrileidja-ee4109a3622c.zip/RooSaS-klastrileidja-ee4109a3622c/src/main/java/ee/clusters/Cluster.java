package ee.clusters;

import ee.words.WordTag;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.util.ArrayList;

public class Cluster {
    String WORDTAGSEPARATOR = "||";

    int count = 0;
    public int clusterSize = 3;
    ArrayList<WordTag> wordTags = new ArrayList<WordTag>();
    ArrayList<String[]> words = new ArrayList<String[]>();

    public Cluster(ArrayList<WordTag> input, int clusterSize) {
        this.clusterSize = clusterSize;
        wordTags = input;
    }

    public void addToWords(ArrayList<WordTag> input) {
        count++;
        String temp[] = new String[clusterSize];
        if (!checkIfNull(input)) {
            int i = 0;
            try {
            } catch (Exception e) {
                e.printStackTrace();
            }

            for (WordTag wordTag : input) {
                temp[i] = wordTag.getName();
                i++;
            }
            words.add(temp);
        }
    }

    public int getClusterSize() {
        return clusterSize;
    }

    public int getCount() {
        return count;
    }

    public ArrayList<String[]> getWords() {
        if (words != null) {
            return words;
        }
        return null;
    }

    public boolean checkIfExists(Cluster input, boolean morphologicalTags, boolean syntacticalTags) { //settings[0] = morphtags, settings[1] synttags, settings[2] _z_tag
        if (input != null) {
            try {
                if (getClusterSize() == input.getClusterSize()) {
                    int counter = 0;
                    for (WordTag wordTag : wordTags) {
                        if (input.wordTags != null) {
                            if (morphologicalTags) {
                                if (!input.wordTags.get(counter).getMorphologicalTag().equalsIgnoreCase(wordTag.getMorphologicalTag())) {
                                    return false;
                                }
                            }
                            if (syntacticalTags) {
                                if (!input.wordTags.get(counter).getSyntacticTag().equalsIgnoreCase(wordTag.getSyntacticTag())) {
                                    return false;
                                }
                            }
                        } else {
                            return false;
                        }

                        counter++;
                    }
                    return true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }
        return false;
    }

    public Object[] getClusterAsObject(String type) {
        Object[] toReturn = new Object[clusterSize + 1];
        for (int i = 0; i < getClusterSize(); i++) {
            if (wordTags != null) {
                if (type.equals("morph"))
                    toReturn[i + 1] = wordTags.get(i).getMorphologicalTag();
                if (type.equals("synt"))
                    toReturn[i + 1] = wordTags.get(i).getSyntacticTag();
                if (type.equals("both"))
                    toReturn[i + 1] = wordTags.get(i).getMorphologicalTag() + " // " + wordTags.get(i).getSyntacticTag();
            }
        }
        toReturn[0] = count;
        return toReturn;
    }

    public boolean checkIfNull(ArrayList<WordTag> list) {
        return list == null || list.contains(null);
    }

    public ArrayList<WordTag> getWordTagCluster() {
        return wordTags;
    }

    public boolean has_Z_Tag(boolean punctuation) {
        if (!punctuation) {
            if (wordTags != null) {
                for (WordTag wordTag : wordTags) {
                    if (wordTag.getWordTypeAsString().equals("_Z_")) {
                        return true;
                    }
                    if (wordTag.getWordTypeAsString().equals("")) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public String getClusterForSave(boolean morphologicalTags, boolean syntacticalTags, boolean wordTagAnalysis) {
        String toReturn = "";
        toReturn += count + " ";
        try {
            for (int i = 0; i < getClusterSize(); i++) {
                if (wordTags.size() < getClusterSize()) {
                    return "";
                }
                if (wordTagAnalysis) {
                    toReturn += "; " + wordTags.get(i).getWordType();
                } else if (morphologicalTags & syntacticalTags)
                    toReturn += "; " + wordTags.get(i).getMorphologicalTag() + " // " + wordTags.get(i).getSyntacticTag();
                else {
                    if (morphologicalTags)
                        toReturn += "; " + wordTags.get(i).getMorphologicalTag();
                    if (syntacticalTags)
                        toReturn += "; " + wordTags.get(i).getSyntacticTag();
                }
            }
            toReturn += "; ";
            for (String[] word : words) {
                toReturn += "; ";
                for (String aWord : word)
                    if (aWord != null)
                        toReturn += aWord + " ";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        toReturn += "\n";
        return toReturn;
    }

    public String getClusterId() {
        String toReturn = "";
        for (WordTag word : wordTags)
            toReturn += word.getMorphologicalTag() + WORDTAGSEPARATOR + word.getSyntacticTag();
        return toReturn;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 31).
                append(getClusterId()).
                toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Cluster))
            return false;
        if (obj == this)
            return true;

        Cluster rhs = (Cluster) obj;
        return new EqualsBuilder().append(getClusterId(), rhs.getClusterId()).isEquals();
    }

}
