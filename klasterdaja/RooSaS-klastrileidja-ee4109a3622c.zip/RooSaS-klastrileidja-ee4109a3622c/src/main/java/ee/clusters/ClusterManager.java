package ee.clusters;

import ee.ui.MainWindow;
import ee.words.WordTag;
import ee.words.WordTagExtractor;

import java.util.ArrayList;


public class ClusterManager {
    MainWindow mainWindow;
    WordTagExtractor wordTagExtractor;

    Clusters clusters = new Clusters();
    int counter = 0;
    int clusterSize = 3;

    public ClusterManager(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
        System.out.println("tekitati cluster manager");
    }

    public ClusterManager() {
    }

    public void addCluster(ArrayList<WordTag> input, AnalyzerSettings settings, int clusterSize) {
        clusters.addCluster(input, settings, clusterSize);
    }

    public ArrayList<WordTag> generateArray(int count) {
        return mainWindow.getWordTagsForCluster(clusterSize, count);
    }

    public ArrayList<WordTag> generateArrayWithoutUI(int counter) {
        return wordTagExtractor.getWordTagsForCluster(clusterSize, counter);
    }

    public void setWordTagExtractor(WordTagExtractor wordTagExtractor) {
        this.wordTagExtractor = wordTagExtractor;
    }

    public ArrayList<WordTag> getWordTagAt(int count) {
        return wordTagExtractor.getWordTagsForCluster(clusterSize, count);
    }

    public void getClusters(AnalyzerSettings settings) {
        this.clusterSize = settings.getClusterSize();
        long startTime = System.currentTimeMillis();
        //int WordTagListSize = mainWindow.getWordTagListSize()-4;
        int wordTagListSize = wordTagExtractor.getWordTagListSize();
        clusters.setSettings(settings);
        ArrayList<WordTag> temp = new ArrayList<WordTag>();
        for (counter = 0; counter < wordTagListSize; counter++) {
            //temp = generateArray(counter);
            temp = generateArrayWithoutUI(counter);
            addCluster(temp, settings, clusterSize);
        }
        System.out.println("Time spent: " + (System.currentTimeMillis() - startTime));
    }


    public void printClusters() {
        clusters.addClustersToTable(mainWindow);
    }

    public ArrayList<String[]> getClusterWords(int selectedRow) {
        return clusters.getClusterWords(selectedRow);

    }

    public int getClusterSize() {
        return clusters.getSize();
    }

    public void clearClusters() {
        clusters.clearClusters();
    }

    public String getClusterForSaveAt(int counter) {
        return clusters.getClusterForSaveAt(counter);
    }

    public Clusters getClusters() {
        return clusters;
    }


}
