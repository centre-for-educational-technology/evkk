package ee.clusters;

import ee.ui.MainWindow;
import ee.words.WordTag;

import java.util.*;


public class Clusters {

    HashMap<String,Cluster> clusters = new HashMap<String, Cluster>();
    List<Cluster> sortedClusters;
    private boolean morphologicalTags = false;
    private boolean syntacticalTags = false;
    private boolean punctuation = false;
    private boolean wordTagAnalysis = false;

    public Clusters() {
    }

    private Cluster createClusterAccordingToSettings(ArrayList<WordTag> input, AnalyzerSettings settings, int clusterSize){
        if(settings.wordTagAnalysis){
            return new WordTagCluster(input, clusterSize);
        }
        if(settings.morphologicalTags && settings.syntacticalTags){
            return new Cluster(input, clusterSize);
        }
        if(settings.morphologicalTags){
            return new MorphologicCluster(input, clusterSize);
        }
        if(settings.syntacticalTags){
            return new SyntacticCluster(input, clusterSize);
        }
        return new Cluster(input, clusterSize);
    }

    public void addCluster(ArrayList<WordTag> input, AnalyzerSettings settings, int clusterSize) {
        if (!checkIfArrayHasNullMember(input)) {
            Cluster temp = createClusterAccordingToSettings(input, settings, clusterSize);
            if (!temp.has_Z_Tag(settings.punctuation)) { // throws out all the tags with _Z_ member(",", ".", "-" etc) if settings dont allow
                if (!checkIfHashmapContainsKey(temp)) {
                    temp.addToWords(input);
                    clusters.put(temp.getClusterId(), temp);
                }else{
                    clusters.get(temp.getClusterId()).addToWords(input);
                }
            }
        }
    }

    public boolean checkIfHashmapContainsKey(Cluster temp){
        Cluster clusterToCheck = clusters.get(temp.getClusterId());
        if(clusterToCheck != null){
            return true;
        }
        return false;
    }

    public boolean checkIfArrayHasNullMember(ArrayList<WordTag> list) {
        return list == null || list.contains(null);
    }

    public void sortClusters(){
        sortedClusters = new ArrayList<Cluster>(clusters.values());
        Collections.sort(sortedClusters, new clusterComparator());
    }

    public void addClustersToTable(MainWindow mainWindow) {
        sortClusters();
        for (Cluster cluster : clusters.values()) {
            if (morphologicalTags && syntacticalTags) {
                mainWindow.addLineToClusterTable(cluster.getClusterAsObject("both"));
            } else {
                if (morphologicalTags)
                    mainWindow.addLineToClusterTable(cluster.getClusterAsObject("morph"));
                if (syntacticalTags)
                    mainWindow.addLineToClusterTable(cluster.getClusterAsObject("synt"));
            }
        }
    }

    public ArrayList<String[]> getClusterWords(int selectedRow) {
        return clusters.get(selectedRow).getWords();

    }

    public void clearClusters() {
        clusters.clear();
    }

    public int getSize() {
        return clusters.size();
    }

    public void setSettings(AnalyzerSettings settings) {
        morphologicalTags = settings.morphologicalTags;
        syntacticalTags = settings.syntacticalTags;
        punctuation = settings.punctuation;
        wordTagAnalysis = settings.wordTagAnalysis;
    }

    public class clusterComparator implements Comparator<Cluster> {
        @Override
        public int compare(Cluster cluster1, Cluster cluster2) {
            return cluster2.getCount() - cluster1.getCount();
        }
    }

    public String getClusterForSaveAt(int counter) {
        return sortedClusters.get(counter).getClusterForSave(morphologicalTags, syntacticalTags, wordTagAnalysis);
    }

    public int getHighestCountCluster() {
        int toReturn = 0;
        for (Cluster cluster : clusters.values()) {
            if (cluster.getCount() > toReturn) {
                toReturn = cluster.getCount();
            }
        }
        return toReturn;
    }

    public String getHighestCountClusterWords() {
        int index = 0;
        int arrayPosition = 0;
        int counter = 0;
        for (Cluster cluster : clusters.values()) {
            if (cluster.getCount() > index) {
                index = cluster.getCount();
                arrayPosition = counter;
            }
            counter++;
        }
        return getClusterForSaveAt(arrayPosition);
    }
}

